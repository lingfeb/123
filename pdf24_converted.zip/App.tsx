import React from 'react';
import Header from './components/Header';
import Profile from './components/Profile';
import Footer from './components/Footer';

const App: React.FC = () => {
  return (
    <div className="min-h-screen flex flex-col font-sans bg-white">
      <Header />
      <div className="flex-grow">
        <Profile />
      </div>
      <Footer />
    </div>
  );
};

export default App;