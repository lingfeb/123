export interface Publication {
  title: string;
  conference: string;
  year: string;
  authors: string;
  award?: string;
}

export interface ProfileData {
  nameCN: string;
  nameEN: string;
  titleCN: string[];
  titleEN: string;
  email: string;
  location: string;
  office: string;
  website: string;
  bioCN: string;
  bioEN: string;
  researchInterestsCN: string;
  researchInterestsEN: string;
  publications: Publication[];
}