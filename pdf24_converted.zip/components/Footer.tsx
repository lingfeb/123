import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-fudan-blue text-white py-12 border-t-4 border-fudan-accent">
      <div className="max-w-7xl mx-auto px-4 md:px-8 grid grid-cols-1 md:grid-cols-3 gap-12">
        
        {/* Column 1: About */}
        <div>
          <h3 className="text-lg font-bold mb-4 text-blue-200">关于实验室</h3>
          <p className="text-sm text-gray-300 leading-relaxed opacity-80">
            具有一定全球影响力、文理学科融合发展的特色科研团队。我们致力于探索计算科学的最前沿，保卫数字世界的边界。
          </p>
        </div>

        {/* Column 2: Contact */}
        <div>
          <h3 className="text-lg font-bold mb-4 text-blue-200">联系实验室</h3>
          <div className="text-sm text-gray-300 space-y-2 opacity-80">
            <p>上海市 杨浦区 淞沪路2005号</p>
            <p>复旦大学江湾校区二号交叉学科楼</p>
            <p>六楼、七楼</p>
            <p className="mt-4 pt-4 border-t border-blue-800">联系邮件: secsys@fudan.edu.cn</p>
          </div>
        </div>

        {/* Column 3: QR Code (Placeholder) */}
        <div>
          <h3 className="text-lg font-bold mb-4 text-blue-200">关注实验室公众号</h3>
          <div className="bg-white p-2 w-32 h-32 rounded-sm">
             {/* QR Code Placeholder */}
             <div className="w-full h-full bg-gray-200 flex items-center justify-center text-gray-400 text-xs text-center">
                QR Code Placeholder
             </div>
          </div>
        </div>
      </div>
      <div className="mt-12 text-center text-xs text-gray-500 border-t border-blue-900 pt-6">
        © 2025 System Software and Security Lab, Fudan University. All Rights Reserved.
      </div>
    </footer>
  );
};

export default Footer;