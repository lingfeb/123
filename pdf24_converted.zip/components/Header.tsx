import React from 'react';
import { Menu, Search, Globe } from 'lucide-react';

const Header: React.FC = () => {
  return (
    <header className="w-full">
      {/* Top Bar */}
      <div className="bg-fudan-blue text-white h-20 px-4 md:px-12 flex items-center justify-between shadow-md">
        <div className="flex items-center gap-4">
           {/* Logo Placeholder - imitating the Fudan logo */}
          <div className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-fudan-blue font-bold text-xl border-2 border-fudan-accent">
            F
          </div>
          <div>
            <h1 className="text-xl md:text-2xl font-medium tracking-wide">系统软件与安全实验室</h1>
            <p className="text-xs md:text-sm text-gray-300 uppercase tracking-wider">System Software & Security Lab</p>
          </div>
        </div>

        <div className="hidden lg:flex items-center space-x-8 text-sm font-medium">
            <nav className="flex space-x-6">
                <a href="#" className="hover:text-blue-300 transition-colors">首页</a>
                <a href="#" className="hover:text-blue-300 transition-colors flex items-center">研究团队 <span className="ml-1 text-[10px]">▼</span></a>
                <a href="#" className="hover:text-blue-300 transition-colors">论文发表</a>
                <a href="#" className="hover:text-blue-300 transition-colors">研究方向</a>
                <a href="#" className="hover:text-blue-300 transition-colors">科研成果</a>
                <a href="#" className="hover:text-blue-300 transition-colors">最新动态</a>
                <a href="#" className="hover:text-blue-300 transition-colors">关于我们</a>
            </nav>
            <div className="flex items-center space-x-3 pl-4 border-l border-gray-600">
                <Search className="w-4 h-4 cursor-pointer hover:text-blue-300" />
                <Globe className="w-4 h-4 cursor-pointer hover:text-blue-300" />
            </div>
        </div>

        {/* Mobile Menu Button */}
        <button className="lg:hidden text-white">
          <Menu className="w-6 h-6" />
        </button>
      </div>

      {/* Breadcrumb Bar */}
      <div className="bg-gray-100 py-3 px-4 md:px-12 border-b border-gray-200">
          <div className="max-w-7xl mx-auto text-sm text-gray-600">
              <span className="hover:underline cursor-pointer">首页</span>
              <span className="mx-2">/</span>
              <span className="hover:underline cursor-pointer">成员</span>
              <span className="mx-2">/</span>
              <span className="font-bold text-fudan-blue">教师</span>
          </div>
      </div>
    </header>
  );
};

export default Header;