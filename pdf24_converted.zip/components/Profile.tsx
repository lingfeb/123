import React from 'react';
import { Mail, MapPin, Home, Award, FileText } from 'lucide-react';
import { PROFILE_DATA, PROFILE_IMAGE_URL } from '../constants';

const Profile: React.FC = () => {
  return (
    <main className="max-w-7xl mx-auto py-12 px-4 md:px-8">
      <h2 className="text-3xl text-gray-800 border-b pb-4 mb-10 font-light">
        教师 <span className="text-sm text-gray-500 ml-2">Faculty</span>
      </h2>

      <div className="flex flex-col md:flex-row gap-12">
        {/* Left Column: Photo & Contact */}
        <div className="w-full md:w-1/3 lg:w-1/4 flex flex-col">
          <div className="w-full aspect-[3/4] bg-gray-200 overflow-hidden shadow-lg mb-6 border-4 border-white rounded-sm relative group">
            <img 
              src={PROFILE_IMAGE_URL} 
              alt={PROFILE_DATA.nameCN}
              className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
              onError={(e) => {
                e.currentTarget.src = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80"; // Fallback
                console.warn("Please place 'yang_wenjie.jpg' in the public directory");
              }}
            />
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/50 to-transparent p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <p className="text-white text-xs text-center font-bold">The Legend</p>
            </div>
          </div>
          
          <div className="mb-6">
            <h1 className="text-2xl font-bold text-fudan-blue mb-1">{PROFILE_DATA.nameCN}</h1>
            <h2 className="text-lg text-gray-600 font-medium">{PROFILE_DATA.titleCN[0]}</h2>
          </div>

          <div className="space-y-3 text-sm text-gray-600">
            <div className="flex items-center gap-3 group cursor-pointer">
              <Mail className="w-4 h-4 text-fudan-accent" />
              <span className="group-hover:text-fudan-blue transition-colors">{PROFILE_DATA.email}</span>
            </div>
            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-fudan-accent mt-1" />
              <div>
                <p>{PROFILE_DATA.location}</p>
                <p>{PROFILE_DATA.office}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 group cursor-pointer">
              <Home className="w-4 h-4 text-fudan-accent" />
              <span className="group-hover:text-fudan-blue transition-colors underline">{PROFILE_DATA.website}</span>
            </div>
          </div>
        </div>

        {/* Right Column: Biography & Content */}
        <div className="w-full md:w-2/3 lg:w-3/4">
          {/* Biography Section */}
          <section className="mb-10">
            <h3 className="text-xl font-bold text-fudan-blue mb-4 flex items-center border-l-4 border-fudan-accent pl-3">
              简介 <span className="text-sm font-normal text-gray-500 ml-2 uppercase">Biography</span>
            </h3>
            
            <div className="prose max-w-none text-gray-700 leading-relaxed text-justify space-y-4">
              <p className="whitespace-pre-line font-medium text-gray-900">
                {PROFILE_DATA.bioCN}
              </p>
              
              <div className="bg-slate-50 p-6 rounded-r border-l-4 border-yellow-500 my-6 shadow-sm">
                  <h4 className="font-bold text-slate-800 mb-2 flex items-center gap-2">
                      <Award className="w-5 h-5 text-yellow-600" />
                      Major Honours (Selected)
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {PROFILE_DATA.titleCN.map((title, idx) => (
                        <span key={idx} className="bg-white border border-gray-200 px-3 py-1 text-xs font-bold text-fudan-blue rounded-full shadow-sm hover:bg-blue-50 transition-colors cursor-default">
                            {title}
                        </span>
                    ))}
                  </div>
              </div>

              <h4 className="text-lg font-bold text-gray-800 mt-8 mb-2">Biography</h4>
              <p className="whitespace-pre-line text-gray-600 italic">
                {PROFILE_DATA.bioEN}
              </p>
              <p className="mt-4 text-gray-600 font-medium">
                 {PROFILE_DATA.titleEN}
              </p>
            </div>
          </section>

          {/* Research Interests */}
          <section className="mb-10">
             <h3 className="text-xl font-bold text-fudan-blue mb-4 flex items-center border-l-4 border-fudan-accent pl-3">
              研究领域 <span className="text-sm font-normal text-gray-500 ml-2 uppercase">Research Interests</span>
            </h3>
            <div className="bg-white border border-gray-200 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow">
                <p className="text-gray-800 mb-2 font-bold">{PROFILE_DATA.researchInterestsCN}</p>
                <p className="text-gray-500 text-sm">{PROFILE_DATA.researchInterestsEN}</p>
            </div>
          </section>

          {/* Selected Publications (Exaggerated) */}
          <section>
             <h3 className="text-xl font-bold text-fudan-blue mb-4 flex items-center border-l-4 border-fudan-accent pl-3">
              代表性论文 <span className="text-sm font-normal text-gray-500 ml-2 uppercase">Selected Publications</span>
            </h3>
            <div className="space-y-4">
                {PROFILE_DATA.publications.map((pub, index) => (
                    <div key={index} className="flex gap-4 p-4 hover:bg-blue-50 transition-colors border-b border-gray-100 last:border-0 rounded-lg">
                        <div className="flex-shrink-0 mt-1">
                            <FileText className="w-6 h-6 text-fudan-accent opacity-50" />
                        </div>
                        <div>
                            <h4 className="text-md font-bold text-gray-800 leading-tight">
                                {pub.title}
                            </h4>
                            <div className="text-sm text-gray-600 mt-1 font-medium">
                                {pub.authors}
                            </div>
                            <div className="text-sm mt-2 flex flex-wrap gap-2 items-center">
                                <span className="font-medium text-fudan-blue italic">{pub.conference} {pub.year}</span>
                                {pub.award && (
                                    <span className="bg-red-100 text-red-700 text-xs px-2 py-0.5 rounded font-bold flex items-center gap-1 shadow-sm border border-red-200">
                                        <Award className="w-3 h-3" /> {pub.award}
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>
          </section>
        </div>
      </div>
    </main>
  );
};

export default Profile;
