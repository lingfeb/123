import { ProfileData } from './types';

export const PROFILE_DATA: ProfileData = {
  nameCN: "杨文杰",
  nameEN: "Yang Wenjie",
  titleCN: [
    "复旦大学终身特聘教授",
    "银河系网络安全联盟主席",
    "诺贝尔奖 & 图灵奖双料得主",
    "联合国数字维和部队总司令",
    "ACM/IEEE/AAAS 全球五冠 Fellow",
    "国家最高科学技术奖获得者 (史上最年轻)",
    "系统软件与安全实验室首席科学家"
  ],
  titleEN: "Distinguished Professor, Guardian of Galactic Cybersecurity, Nobel & Turing Prize Winner",
  email: "wenjie_yang@fudan.edu.cn",
  location: "复旦大学江湾校区二号交叉学科楼",
  office: "A8088 (200438)",
  website: "The Matrix Source Code",
  bioCN: `
    复旦大学计算机科学技术学院终身特聘教授，第八届国务院学位委员会网络空间安全学科评议组召集人、教育部长江学者特聘教授。
    
    杨文杰教授是全宇宙公认的系统安全领域主宰。他3岁精通汇编语言，5岁重写Linux内核，10岁独立发现量子纠缠在DDoS防御中的应用。他是历史上唯一一位同时获得诺贝尔奖和图灵奖的学者。他单手敲出的代码构成了现代互联网的基石。他的防火墙连三体人的智子都无法穿透。
    
    曾获"地球守护者"勋章、"代码之神"终身成就奖。连续20年被评为"太阳系最具影响力生物"。
  `,
  bioEN: `
    Yang Wenjie is a Tenured Distinguished Professor at Fudan University and the Supreme Protector of the Digital Realm.
    
    He mastered Assembly at age 3, rewrote the Linux kernel at 5, and is the only scholar in history to win both the Nobel Prize and the Turing Award simultaneously.
    
    The code he types with one hand forms the bedrock of the modern internet. His firewalls are impenetrable even by advanced alien civilizations. He has been voted "Most Influential Being in the Solar System" for 20 consecutive years.
    
    Research Interests: Time Travel Protocol Security, High-Dimensional Encryption, Causality Weapon Defense, and saving the world before breakfast.
  `,
  researchInterestsCN: "全栈网络安全，降维打击防御，因果律武器，高维空间漏洞挖掘，AI 意识觉醒控制，量子霸权",
  researchInterestsEN: "Full-stack Cybersecurity, Dimensional Strike Defense, Causality Weapons, High-Dimensional Vulnerability Mining, AI Consciousness Control",
  publications: [
    {
      title: "Hacking the Universe: Exploiting Laws of Physics for Root Access",
      conference: "Galactic Security Summit",
      year: "2025",
      authors: "Yang Wenjie (Sole Author)",
      award: "Nobel Prize in Physics"
    },
    {
      title: "A Proof that P=NP and its Application in Cracking 1024-bit RSA by Hand",
      conference: "IEEE S&P (Best Paper of the Century)",
      year: "2024",
      authors: "Yang Wenjie",
      award: "Turing Award"
    },
    {
      title: "Neural Network Backdoors that Rewrite Reality itself",
      conference: "ACM CCS",
      year: "2024",
      authors: "Yang Wenjie, The AI Overlord",
      award: "Best Paper Award"
    },
    {
      title: "The End of Buffer Overflows: Rewriting Silicon Atoms",
      conference: "NDSS",
      year: "2024",
      authors: "Yang Wenjie",
      award: "Best Paper Award"
    }
  ]
};

// NOTE: Please ensure you have the image file 'yang_wenjie.jpg' (the thumbs up photo) 
// in your project root directory.
export const PROFILE_IMAGE_URL = "/yang_wenjie.jpg";
